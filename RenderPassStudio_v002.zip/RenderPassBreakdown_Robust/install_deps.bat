@echo off
setlocal
cd /d "%~dp0"

echo ================================================
echo  Render Pass Studio - Install dependencies
echo ================================================
echo.
echo  Packages:
echo    PySide6, numpy, Pillow, imageio, imageio-ffmpeg, OpenEXR
echo.

where python >nul 2>&1
if errorlevel 1 (
  echo ERROR: Python not found on PATH.
  echo Install Python 3.10+ from https://www.python.org/downloads/
  echo Enable "Add python.exe to PATH" during setup.
  pause
  exit /b 1
)

python -m pip install --upgrade pip
if errorlevel 1 goto :fail

python -m pip install -r requirements.txt
if errorlevel 1 goto :fail

echo.
echo Checking FFmpeg bundle...
python -c "import imageio_ffmpeg; print('FFmpeg OK:', imageio_ffmpeg.get_ffmpeg_exe())"
if errorlevel 1 (
  echo Warning: imageio-ffmpeg check failed - MP4 export may need a retry.
)

echo.
echo ================================================
echo  Install complete.
echo  Run the studio with:  run.bat
echo ================================================
goto :done

:fail
echo.
echo ================================================
echo  Install FAILED. Read the error above.
echo  Then run install_deps.bat again.
echo ================================================
exit /b 1

:done
pause
endlocal
